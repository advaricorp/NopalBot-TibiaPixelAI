"""
PBT GUI Package
Graphical User Interface for the bot
"""

__version__ = "2.0.0"
__author__ = "Taquito Loco" 