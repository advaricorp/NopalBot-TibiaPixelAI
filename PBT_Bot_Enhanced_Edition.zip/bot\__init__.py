"""
PBT Bot Package
Main bot logic and core functionality
"""

__version__ = "2.0.0"
__author__ = "Taquito Loco" 